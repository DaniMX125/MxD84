# Package MXD84
# contain my usefull information