# Subpackage MXD84 - utilities 
# contain my utilities function